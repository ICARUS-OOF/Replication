Controls:
- WASD to move around.
- Spacebar to interact and select actions.
- AD to navigate items and abilities.
- 1234 to select choices and buy vending machine items.

How to play:
- To win the game, defeat all enemies and reach the exit to escape.
- Most props in the environment can be interacted with.
- Interact with vending machines to buy items with Gcoins. Gcoins can be earned from winning battles.
                |-|
- Interact with |I| to gain items.
                |-|
- Unlock the exit by interacting with a specific prop in the armory.