#pragma once
#include <string>
class AudioHandler
{
public:
	static void PlaySFX(std::string sfxID);
};

