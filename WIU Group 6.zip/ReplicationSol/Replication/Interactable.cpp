#include "Interactable.h"

// Empty because this class is abstract