#include "Intro.h"
#include <iostream>
#include <windows.h>
#include <chrono>
#include "AudioHandler.h"
#include <thread> 
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
#include <conio.h>



/// <summary>
/// JUN SHEN
/// 
/// Play the game logo animation after the story animation and waits for player input
/// </summary>
void Intro::PlayIntro() {



bool animend = false;
bool inputgotten = false;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
//Logo animation
std::cout << R"(
                                          ______          
                                   . '   /\  == \   ' .   
                                *     *  \ \  __<  *     *
                                   ' .    \ \_\ \_\ . '   
                                           \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");


        std::cout << R"(
                                          ______          
                                      '  /\  == \   .  
                                 *   *   \ \  __<      *
                                     .    \ \_\ \_\   '   
                                           \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                          ______            
                               .   '     /\  == \            
                                   *     \ \  __<     *           
                                 '        \ \_\ \_\   .   '   
                                           \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                          ______            
                                         /\  == \            
                                         \ \  __<                
                                          \ \_\ \_\        
                                           \/_/ /_/       
)" << '\n';

        Sleep(200);
        system("cls");


        std::cout << R"(
                                        ______   ______          
                                   . ' /\  == \ /\  == \   ' .   
                                *     *\ \  __< \ \  __<  *     *
                                   ' .  \ \_\ \_\\ \_\ \_\ . '   
                                         \/_/ /_/ \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                        ______   ______          
                                    '  /\  == \ /\  == \    '   
                               *       \ \  __< \ \  __<   *    
                                        \ \_\ \_\\ \_\ \_\   .   '
                                  '      \/_/ /_/ \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                   '    ______   ______           
                                       /\  == \ /\  == \         
                            *          \ \  __< \ \  __<        '
                                        \ \_\ \_\\ \_\ \_\      
                                 '       \/_/ /_/ \/_/ /_/    .   
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                        ______   ______           
                                       /\  == \ /\  == \         
                                       \ \  __< \ \  __<       
                                        \ \_\ \_\\ \_\ \_\      
                                         \/_/ /_/ \/_/ /_/      
)" << '\n';

        Sleep(200);
        system("cls");

        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \   ' .   
                               . ' \ \  __< \ \  __< \ \  __<  *     *
                            *     * \ \_\ \_\\ \_\ \_\\ \_\ \_\ . '   
                               ' .   \/_/ /_/ \/_/ /_/ \/_/ /_/       
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \     '  
                           *    '  \ \  __< \ \  __< \ \  __<         *
                               *    \ \_\ \_\\ \_\ \_\\ \_\ \_\    '   
                                .    \/_/ /_/ \/_/ /_/ \/_/ /_/  .     
)" << '\n';

        Sleep(50);
        system("cls");


        std::cout << R"(
                                    ______   ______   ______          ' 
                              '    /\  == \ /\  == \ /\  == \        
                          *        \ \  __< \ \  __< \ \  __<           *
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                               .     \/_/ /_/ \/_/ /_/ \/_/ /_/    .       
)" << '\n';

        Sleep(50);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
               ______  __                                                    __   __   
              /\  == \/\ \                                                  /\ "-.\ \  
              \ \  _-/\ \ \____                                             \ \ \-.  \ 
               \ \_\   \ \_____\                                             \ \_\\"\_\
                \/_/    \/_____/                                              \/_/ \/_/   
)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
                ______  __       __                                           __   __   
               /\  == \/\ \     /\ \                                         /\ "-.\ \  
               \ \  _-/\ \ \____\ \ \                                        \ \ \-.  \ 
                \ \_\   \ \_____\\ \_\                                        \ \_\\"\_\
                 \/_/    \/_____/ \/_/                                         \/_/ \/_/
)";

        Sleep(100);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __                                         __   __   
        /\  ___\ /\  == \/\ \     /\ \                                       /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \                                      \ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\                                      \ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/                                       \/_/ \/_/
)";

        Sleep(100);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __           ______                          __   __   
        /\  ___\ /\  == \/\ \     /\ \         /\  __ \                        /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \        \ \  __ \                       \ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\        \ \_\ \_\                       \ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/         \/_/\/_/                        \/_/ \/_/
)";

        Sleep(100);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __           ______   ______                 __   __   
        /\  ___\ /\  == \/\ \     /\ \         /\  __ \ /\__  _\               /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \        \ \  __ \\/_/\ \/               \ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\        \ \_\ \_\  \ \_\                \ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/         \/_/\/_/   \/_/                 \/_/ \/_/
)";

        Sleep(100);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______                __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\              /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/              \ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\               \ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/                \/_/ \/_/
)";

        Sleep(100);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __            __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \          /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \         \ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\         \ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/          \/_/ \/_/
)";

        Sleep(100);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        Sleep(100);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(

)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
#######
)";

        Sleep(50);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
#####################
)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##################################
)";

        Sleep(50);
        system("cls");



        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
####################################################
)";

        Sleep(50);
        system("cls");



        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################
)";

        Sleep(50);
        system("cls");



        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################
)";

        Sleep(50);
        system("cls");


        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        Sleep(100);
        system("cls");



        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
        std::cout << R"(
                                         __  __   
                                        /\ \/\ \  
                                        \ \ \ \ \ 
                                         \ \_\ \_\
                                          \/_/\/_/
)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
        std::cout << R"(
                                         __  ______  __   
                                        /\ \/\  ___\/\ \  
                                        \ \ \ \ \__ \ \ \ 
                                         \ \_\ \_____\ \_\
                                          \/_/\/_____/\/_/
)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   ______   ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
        std::cout << R"(
                                     __  ______  ______  __  __   
                                    /\ \/\  ___\/\  ___\/\ \/\ \  
                                    \ \ \ \  __\\ \ \__ \ \ \ \ \ 
                                     \ \_\ \_____\ \_____\ \_\ \_\
                                      \/_/\/_____/\/_____/\/_/\/_/
)";

        Sleep(50);
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
        std::cout << R"(
                             __  ______  ______  ______  __  __   __  __   
                            /\ \/\  == \/\  ___\/\  ___\/\ \/\ "-.\ \/\ \  
                            \ \ \ \  __<\ \  __\\ \ \__ \ \ \ \ \-.  \ \ \ 
                             \ \_\ \_____\ \_____\ \_____\ \_\ \_\\"\_\ \_\
                              \/_/\/_____/\/_____/\/_____/\/_/\/_/ \/_/\/_/
)";

        Sleep(50);
        system("cls");

        animend = true;
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
        std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
        std::cout << R"(
         ______   ______  __       __   __ ____  ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
        std::cout << R"(
##############################################################################################################
)";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
        std::cout << R"(
                         __      ______  ______  ______  __  __   __      __   
                        /\ \    /\  == \/\  ___\/\  ___\/\ \/\ "-.\ \    /\ \  
                        \ \ \   \ \  __<\ \  __\\ \ \__ \ \ \ \ \-.  \   \ \ \ 
                         \ \_\   \ \_____\ \_____\ \_____\ \_\ \_\\"\_\   \ \_\
                          \/_/    \/_____/\/_____/\/_____/\/_/\/_/ \/_/    \/_/
)";

        Sleep(750);
        system("cls");

        while (animend && !inputgotten) {

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
            std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
            std::cout << R"(
         ______   ______  __       __   ______   ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
            std::cout << R"(
##############################################################################################################
)";

            Sleep(750);
            system("cls");



            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
            std::cout << R"(
                                    ______   ______   ______          
                                   /\  == \ /\  == \ /\  == \        
                                   \ \  __< \ \  __< \ \  __<          
                                    \ \_\ \_\\ \_\ \_\\ \_\ \_\        
                                     \/_/ /_/ \/_/ /_/ \/_/ /_/          
)";

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
            std::cout << R"(
         ______   ______  __       __   ______   ______   ______  __   ______   __   __   
        /\  ___\ /\  == \/\ \     /\ \ /\  ___\ /\  __ \ /\__  _\/\ \ /\  __ \ /\ "-.\ \  
        \ \  __\ \ \  _-/\ \ \____\ \ \\ \ \____\ \  __ \\/_/\ \/\ \ \\ \ \/\ \\ \ \-.  \ 
         \ \_____\\ \_\   \ \_____\\ \_\\ \_____\\ \_\ \_\  \ \_\ \ \_\\ \_____\\ \_\\"\_\
          \/_____/ \/_/    \/_____/ \/_/ \/_____/ \/_/\/_/   \/_/  \/_/ \/_____/ \/_/ \/_/
)";

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 8);
            std::cout << R"(
##############################################################################################################
)";

            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
            std::cout << R"(
                         __      ______  ______  ______  __  __   __      __   
                        /\ \    /\  == \/\  ___\/\  ___\/\ \/\ "-.\ \    /\ \  
                        \ \ \   \ \  __<\ \  __\\ \ \__ \ \ \ \ \-.  \   \ \ \ 
                         \ \_\   \ \_____\ \_____\ \_____\ \_\ \_\\"\_\   \ \_\
                          \/_/    \/_____/\/_____/\/_____/\/_/\/_/ \/_/    \/_/
)";

            std::cout << "\n\n\n                                     SELECT   ANY   KEY   TO   BEGIN";
            Sleep(750);
            system("cls");

            if (_kbhit()) {
                _getch();
                inputgotten = true;
            }
        }
    }

    /// <summary>
    /// JUN SHEN
    /// 
    /// Plays the story animation at the start of the game and waits for player input
    /// </summary>
    void Intro::PlayInCut() {

        std::cout << R"(
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|H|         /\ \ \ \/_______/     ______/\      \  /\ \/ /\ \/ /\  \____________       |H|
|H|        /\ \ \ \/______ /     /\    /:\\      \ ::\  /::\  /::\ /____  ____ _       |H|
|H|       /\ \ \ \/_______/     /:\\  /:\:\\______\::/  \::/  \::///   / /   //        |H|
|H|      /\ \ \ \/_______/    _/____\/:\:\:/_____ / / /\ \/ /\ \///___/ /___//__      /|H|
|H|_____/___ \ \/_______/    /\::::::\\:\:/_____ / \ /::\  /::\ /____  ____  ________/_|H|
|H|         \ \/_______/    /:\\::::::\\:/_____ /   \\::/  \::///   / /   / /          |H|
|H|          \/_______/    /:\:\\______\/______/_____\\/ /\ \///___/ /___/ /____       |H|
|H|\          \______/    /:\:\:/_____:/\      \ ___ /  /::\ /____  ____  _/\:::\      |H|
|H|\\__________\____/    /:\:\:/_____:/:\\      \__ /_______/____/_/___/_ /  \::\\_____|H|
|H|//__________/___/   _/____:/_____:/:\:\\______\ /                     /\  /\://_____|H|
|H|///\          \/   /\ .----.\___:/:\:\:/_____ // \                   /  \/  \///\   |H|
|H|///\\          \  /::\\ \_\ \\_:/:\:\:/_____ //:\ \                 /\  /\  ////\\  |H|
|H|//:/\\          \//\::\\ \ \ \\/:\:\:/_____ //:::\ \               /  \/  \/+//:/\\ |H|
|H|/:/:/\\_________/:\/:::\`----' \\:\:/_____ //o:/\:\ \_____________/\  /\  / //:/:/\\|H|
|H|:/:/://________//\::/\::\_______\\:/_____ ///\_\ \:\/____________/  \/  \/+/\:/:/://|H|
|H|/:/:///_/_/_/_/:\/::\ \:/__  __ /:/_____ ///\//\\/:/ _____  ____/\  /\  / /  /:/:///|H|
|H|:/:///_/_/_/_//\::/\:\///_/ /_//:/______/_/ :~\/::/ /____/ /___/  \/  \/+/\  :/:///_|H|
|H|/:///_/_/_/_/:\/::\ \:/__  __ /:/____/\  / \\:\/:/ _____  ____/\  /\  / /  \//:///_/|H|
|H|:///_/_/_/_//\::/\:\///_/ /_//:/____/\:\____\\::/ /____/ /___/  \/  \/+/\  /\:///_/_|H|
|H|///_/_/_/_/:\/::\ \:/__  __ /:/____/\:\/____/\\/____________/\  /\  / /  \/  ///_/_/|H|
|H|//_/_/_/_//\::/\:\///_/ /_//::::::/\:\/____/  /----/----/--/  \/  \/+/\  /\  //_/_/_|H|
|H|/_/_/_/_/:\/::\ \:/__  __ /\:::::/\:\/____/ \/____/____/__/\  /\  / /  \/  \//_/_/_/|H|
|H|_/_/_/_//\::/\:\///_/ /_//\:\::::\:\/____/ \_____________/  \/  \/+/\  /\  / _/_/_/_|H|
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||


)" << '\n';

        const char* text = "\nIn the outskirts of a bustling city.\n";
        for (const char* p = text; *p; ++p) {
            std::cout << *p << std::flush;
            AudioHandler::PlaySFX("typing");
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
        }
        std::cout << "Press any key to continue..." << std::endl;
        std::cout << "Press 'F' to skip intro..." << std::endl;
        {
            int option = _getch();
            system("cls");
            if (option == 'f' || option == 'F')
                return;
        }
        system("cls");


        std::cout << R"(
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|H|                                          H                                         |H|
|H|                                          H                              HH         |H|
|H|          HHH                     HHHHHHHHHHHHHHHHHHHHH                HHH          |H|
|H|           HHH               HHHHHHHHHHHHHHHHHHHHHHHHHHHHHH           H             |H|
|H|             HH          HHHHHHHHH... ...................HHHHH                      |H|
|H|                      HHHHH .. ........HHHHHHHHH.............HHHH                   |H|
|H|                   HHHHH............HHHHHHHHHHHHHHHHH .........HHHHH                |H|
|H|                HHHH..............HH HHxxxxOOOxHxxx HHH .... .....HHHH              |H|
|H|              HHH.................H x xxxxOOOOOOHxxxHHHH.............HHH            |H|
|H|           HHHH.................. HHx xxHxOOOOxOOxxxxxH H.......... ....HHHH        |H|
|H|        HHHH..................... HHx xxHxOOOOxxOxHH xxHH................HHHH       |H|
|H|    HHHHH........................ HHx xxxxOOOOOOOHH xxxHH...............HHHHHHHH    |H|
|H|        HHH.......................HH xxxxxxxxxxxxxxxxHH...  ........... HHHHH       |H|
|H|         HHHH..................... HHHHH xxxx HH H HHH... ........... HHHH          |H|
|H|          HHHHH...................... HHHHHHHHHHHHHHH .............HHHHHH           |H|
|H|            HHHHH.......................H.HHHHHHH...............HHHHHH              |H|
|H|              HHHHHHHHH...................................HHHHHH                    |H|
|H|                    HHHHHHHHH........................HHHHHHHHH                      |H|
|H|                        HHHH HHHHHHHHHHHHHHHHHHHHHHHHHHHH                           |H|
|H|               HHH              HHHHHHHHHHHHHHHHHHH                                 |H|
|H|             HHH                          H                       HH                |H|
|H|                                          H                        HH               |H|
|H|                                          H                                         |H|
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||


)" << '\n';

        text = "\nWhere hidden from public eyes.\n";
        for (const char* p = text; *p; ++p) {
            std::cout << *p << std::flush;
            AudioHandler::PlaySFX("typing");
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
        }
        std::cout << "Press any key to continue..." << std::endl;
        std::cout << "Press 'F' to skip intro..." << std::endl;
        {
            int option = _getch();
            system("cls");
            if (option == 'f' || option == 'F')
                return;
        }
        system("cls");


        std::cout << R"(
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|H|---------------------------------H|||||||||||||||||||||||||||||||||||||||||||||||||||||
|H|---------------------------------HH||||||||||||||||||||||||||||||||||||||||||||||||||H|
|H|----------------------------------HH|||||||||||||||||||||||||||||||||||||||||||||||||H|
|H|-----------------------------------HH||||||||||||||||||||||||||||||||||||||||||||||||H|
|H|------------------------------------H||||H|||||||||||||||||||||||||||||||||||||||||||H|
|H|------------------------------------H||||HHH|||||||||||||||||||||||||||||||||||||||||H|
|H|------------------------------------H||||H  HH|||||||||||||||||||||||||||||||||||||||H|
|H|------------------------------------H||||H   H|||||||||||||||||||||||||||||||||||||||H|
|H|-------------------------------------H|||HHH H|||||||||||||||||||||||||||||||||||||||H|
|H|-------------------------------------HH|||HH HHH|||||||||||||||||||||||||||||||||||||H|
|H|---------------------------------------H||HH   HHHHHHH|||||||||||||||||||||||||||||||H|
|H|---------------------------------------HH|HHH        HHHH||||||||||||||||||||||||||||H|
|H|----------------------------------------HH||HHH         HHHHHH|||||||||||||||||||||||H|
|H|-----------------------------------------HH|||HHHH           HHHHHHH|||||||||||||||||H|
|H|------------------------------------------HH||||HHH               HH|HHHH|HHHHHHHHHH|H|
|H|-------------------------------------------HHH||||HHHH                              |H|
|H|----------------------------------------------H|||||HHHH                            |H|
|H|----------------------------------------------HHH|||||||HHH                         |H|
|H|------------------------------------------------HH |||||||HHHHH                     |H|
|H|--------------------------------------------------HH||||||||||HHHHH                  H|
|H|----------------------------------------------------HHH|||||||||||HHHHH             |H|
|H|------------------------------------------------------HHH|H|||||||||||HHHHHHHHHH    |H|
|H|----------------------------------------------------------HHH||||||||||||||||||HHHHH|H|
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||


)" << '\n';

        text = "\nDeep inside a secret brews... A conspiracy slowly unravels.\n";
        for (const char* p = text; *p; ++p) {
            std::cout << *p << std::flush;
            AudioHandler::PlaySFX("typing");
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
        }
        std::cout << "Press any key to continue..." << std::endl;
        std::cout << "Press 'F' to skip intro..." << std::endl;
        {
            int option = _getch();
            system("cls");
            if (option == 'f' || option == 'F')
                return;
        }
        system("cls");

        std::cout << R"(
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|H|                                                                                    |||
|H|                  ______            ______    ______   ______    ______             |H|
|H|                 //   ) )          //   ) )  //   ) ) //   ) )  //   ) )            |H|
|H|                //___/ /          //        //   / / //___/ /  //___/ /             |H|
|H|               / ___ (           //        //   / / / ___ (   / ____ /              |H|
|H|              //   | |          //        //   / / //   | |  //                     |H|
|H|             //    | |      () ((____/ / ((___/ / //    | | //                      |H|
|H| -----------------------------------------------------------------------------------|H|
|H|                                                                                    |H|
|H|                              Replication Corporation.                              |H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H| -----------------------------------------------------------------------------------|H|
|H|HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|H|
|||HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH|||


)" << '\n';

        text = "\nInside a labatory where your journey begins... A journey about....\n";
        for (const char* p = text; *p; ++p) {
            std::cout << *p << std::flush;
            AudioHandler::PlaySFX("typing");
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
        }
        std::cout << "Press any key to continue..." << std::endl;
        std::cout << "Press 'F' to skip intro..." << std::endl;
        {
            int option = _getch();
            system("cls");
            if (option == 'f' || option == 'F')
                return;
        }
        system("cls");

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
            text = "\nUNCOVERING  THE  TRUTH  AND  FACING  YOUR  DESTINY .\n";
        for (const char* p = text; *p; ++p) {
            std::cout << *p << std::flush;
            AudioHandler::PlaySFX("typing");
            std::this_thread::sleep_for(std::chrono::milliseconds(70));
        }
        std::cout << "Press any key to continue...";

        _getch();
        system("cls");
        PlayIntro();
    }

    void Intro::PlayBootupScreen()
    {
        AudioHandler::PlaySFX("item");
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
        std::cout << R"(
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");

        std::cout << R"(
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
##############################################################################################################
)" << '\n';

        Sleep(50);
        system("cls");



        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);
        system("cls");
    }
