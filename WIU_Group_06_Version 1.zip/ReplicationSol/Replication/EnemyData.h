#pragma once
#include <string>
#include <vector>

class EnemyData
{
public:
	enum ENEMYTYPE {
		MUTANT,
		HEALER,
		GUARD,
		BOSS
	};

private:
	int health;
	int attack;
	int maxhealth;
	ENEMYTYPE enemyType;
	std::string enemyDescription;
	std::string enemySprite;


public:
	EnemyData(int health, int attack, ENEMYTYPE enemyType);
	void SetAnimations();

	int GetHealth();
	int GetAttack();
	int GetMaxHealth();
	bool DamageEnemy(int amt);
	void HealEnemy(int amt);
	ENEMYTYPE GetEnemyType();
	std::string GetEnemyName();
	bool IsDead();
	bool IsAlive();
	void ResetEnemyHealth();
	std::string GetEnemyDescription();
	static std::string EnemyTypeToString(ENEMYTYPE enemyType);
	static std::string EnemyTypeToAbilityString(ENEMYTYPE enemyType);


	std::string currentFrame;

	std::string idleFrame;
	std::vector<std::string> enemyFrames_attack, enemyFrames_damaged, enemyFrames_ability, enemyFrames_death;
};

