#pragma once
class Intro
{
public:
	void PlayIntro();
	void PlayInCut();
	void PlayBootupScreen();

};

